<?php
require('index.phtml');
?>