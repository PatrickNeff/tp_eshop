<?php

require('index.phtml');
?>