
--
-- Contenu de la table `category`
--

INSERT INTO `category` (`id_category`, `name`, `description`, `time_update`) VALUES
(1, 'fruits', 'sérieux? vous savez pas ce que c''est qu''un fruit??? ', '2015-05-29 11:47:57'),
(2, 'legumes', 'sérieux? vous savez pas ce que c''est qu''un légume???', '2015-05-29 11:47:28'),
(5, 'fruits exotiques', 'des fruits pas de chez nous ', '2015-05-29 11:48:04'),
(6, 'fruits secs', 'des fruits pas très humides ', '2015-05-29 11:48:12');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
