<?php
require('./views/footer.phtml');
?>