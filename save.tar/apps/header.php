<?php
require('./views/header.phtml');
?>